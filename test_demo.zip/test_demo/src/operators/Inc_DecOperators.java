package operators;

public class Inc_DecOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int i = 3;
	        i++;
	        // prints 4
	        System.out.println(i);
	        ++i;			   
	        // prints 5
	        System.out.println(i);
	        // prints 6
	        System.out.println(++i);
	        // prints 6
	        System.out.println(i++);
	        // prints 7
	        System.out.println(i);
	}

}
