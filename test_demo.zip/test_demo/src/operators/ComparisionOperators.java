package operators;

public class ComparisionOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int value1 = 1;
	        int value2 = 2;
	        if(value1 == value2)
	            System.out.println("value1 == value2");
	        if(value1 != value2)
	            System.out.println("value1 != value2");
	        if(value1 > value2)
	            System.out.println("value1 > value2");
	        if(value1 < value2)
	            System.out.println("value1 < value2");
	        if(value1 <= value2)
	            System.out.println("value1 <= value2");
	}

}
