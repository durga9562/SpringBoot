package test_demo;

public class ImpliciteDataTypeConversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 100;
		System.out.println("Int Representation: " + a);

		long b = a;
		System.out.println("long Representation :" + b);

		float c = b;
		System.out.println("Float Representation :" + c);
	}

}
