package test_demo;

public class PrimitiveDataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char a='A';
 byte b=2;
 short c=22;
 int d=45;
 float e=5.23232f;
 double f=4.4554788567754d;
 boolean g=true;
 
 System.out.println("char:"+ a);
 System.out.println("byte :"+ b);
 System.out.println("short :"+ c);
 System.out.println("int :"+ d);
 System.out.println("float :"+ e);
 System.out.println("double :"+ f);
 System.out.println("boolean :"+ g);

	}

}
