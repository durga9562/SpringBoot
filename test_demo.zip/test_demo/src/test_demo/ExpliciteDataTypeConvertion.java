package test_demo;

public class ExpliciteDataTypeConvertion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double a = 50.50;
System.out.println("Double Reprsentation :"+ a);

float f=(float)a;
System.out.println("Float Representation :"+ f);

long b=(long)a;
System.out.println("Long Reprsentation :"+ b);

int c=(int)b;
System.out.println("Int Representation :"+ c);
	}

}
